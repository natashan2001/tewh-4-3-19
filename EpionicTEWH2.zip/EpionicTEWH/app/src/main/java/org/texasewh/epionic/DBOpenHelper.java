package org.texasewh.epionic;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

class DBOpenHelper extends SQLiteOpenHelper {
    public static final String DATABASE = "memos.db";
    public static String TABLE = "memo";
    private static final String KEY_ID = "id";
    public static String TABLE_temp = "temperature";
    public static final int VERSION = 1;

    public DBOpenHelper(Context context) {
        super(context, DATABASE, null, VERSION);
    }
    private static final String CREATE_TABLE = "CREATE TABLE "
            + TABLE + "(date INTEGER PRIMARY KEY, memo TEXT)";
    private static final String CREATE_TABLE_Temp = "CREATE TABLE "
            + TABLE_temp + "(date INTEGER PRIMARY KEY, tempdata INTEGER)";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
        db.execSQL(CREATE_TABLE_Temp);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public Temperature getTemp(long temp_id) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_temp + " WHERE "
                + KEY_ID + " = " + temp_id;

        Log.e("DatabaseHelper", selectQuery);

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null)
            c.moveToFirst();

        Temperature temperature = new Temperature();
        temperature.setInteger(c.getInt(c.getColumnIndex(KEY_ID)));
        return temperature;
    }
    public List<Temperature> getAllTemp() {
        List<Temperature> temps = new ArrayList<Temperature>();
        String selectQuery = "SELECT  * FROM " + TABLE_temp;

        Log.e("DatabaseHelper", selectQuery);

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                Temperature td = new Temperature();
                td.setInteger(c.getInt(c.getColumnIndex(KEY_ID)));

                // adding to todo list
                temps.add(td);
            } while (c.moveToNext());
        }

        return temps;
    }

}