package org.texasewh.epionic;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DatabaseAccess extends AppCompatActivity {
    private SQLiteDatabase database;
    private DBOpenHelper openHelper;
    private static volatile DatabaseAccess instance;

    private DatabaseAccess(Context context) {
        this.openHelper = new DBOpenHelper(context);
    }
    public DatabaseAccess (){

    }

    public static synchronized DatabaseAccess getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseAccess(context);
        }
        return instance;
    }

    public void open() {
        this.database = openHelper.getWritableDatabase();
    }

    public void close() {
        if (database != null) {
            this.database.close();
        }
    }
    public void save(Temperature temp){
        ContentValues values = new ContentValues();
        values.put("date", temp.getTime());
        values.put("tempdata", temp.getInteger());
        database.insert(DBOpenHelper.TABLE, null, values);
    }
    public void update(Temperature temp) {
        ContentValues values = new ContentValues();
        values.put("date", new Date().getTime());
        values.put("tempdata", temp.getInteger());
        String date = Long.toString(temp.getTime());
        database.update(DBOpenHelper.TABLE, values, "date = ?", new String[]{date});
    }

    public void save(NotesActivity.Memo memo) {
        ContentValues values = new ContentValues();
        values.put("date", memo.getTime());
        values.put("memo", memo.getText());
        database.insert(DBOpenHelper.TABLE, null, values);
    }

    public void update(NotesActivity.Memo memo) {
        ContentValues values = new ContentValues();
        values.put("date", new Date().getTime());
        values.put("memo", memo.getText());
        String date = Long.toString(memo.getTime());
        database.update(DBOpenHelper.TABLE, values, "date = ?", new String[]{date});
    }

    public void delete(NotesActivity.Memo memo) {
        String date = Long.toString(memo.getTime());
        database.delete(DBOpenHelper.TABLE, "date = ?", new String[]{date});
    }

    public List getAllMemos() {
        List memos = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT * From memo ORDER BY date DESC", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            long time = cursor.getLong(0);
            String text = cursor.getString(1);
            memos.add(new NotesActivity.Memo(time, text));
            cursor.moveToNext();
        }
        cursor.close();
        return memos;
    }
}