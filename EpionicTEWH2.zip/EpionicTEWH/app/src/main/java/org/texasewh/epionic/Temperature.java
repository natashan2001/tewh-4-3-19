package org.texasewh.epionic;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Temperature {

   // public static class temperature implements Serializable {
        private Date date;
        private Integer tempdata;
        private boolean fullDisplayed;
        private DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyy 'at' hh:mm aaa");

        public void Temperature() {
            this.date = new Date();
        }

        public void Temperature(long time, int tempdata) {
            this.date = new Date(time);
            this.tempdata= new Integer(tempdata);

        }

        public String getDate() {
            return dateFormat.format(date);
        }

        public long getTime() {
            return date.getTime();
        }

        public void setTime(long time) {
            this.date = new Date(time);
        }

        public void setInteger(Integer tempdata) {
            this.tempdata = tempdata;
        }

        public Integer getInteger() {
            return this.tempdata;
        }

       /* public void setFullDisplayed(boolean fullDisplayed) {
            this.fullDisplayed = fullDisplayed;
        }

        public boolean isFullDisplayed() {
            return this.fullDisplayed;
        }*/

        public Integer toInteger(Temperature x) {
            return x.tempdata;
        }
    //}
}
